minetest.register_node(":firealarm:hornstrobe_off",{
	description = "Fire Alarm",
	groups = { oddly_breakable_by_hand = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		"firealarm_hornstrobe_front_off.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("notification",pos,{strobeActive = false,hornActive = false})
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("notification",pos,nil)
	end,
})

local hornstrobeOnFrontTexture = "[combine:32x320"..
                                 ":0,0=firealarm_hornstrobe_front_on.png"..
                                 ":0,32=firealarm_hornstrobe_front_off.png"..
                                 ":0,64=firealarm_hornstrobe_front_off.png"..
                                 ":0,96=firealarm_hornstrobe_front_off.png"..
                                 ":0,128=firealarm_hornstrobe_front_off.png"..
                                 ":0,160=firealarm_hornstrobe_front_off.png"..
                                 ":0,192=firealarm_hornstrobe_front_off.png"..
                                 ":0,224=firealarm_hornstrobe_front_off.png"..
                                 ":0,256=firealarm_hornstrobe_front_off.png"..
                                 ":0,288=firealarm_hornstrobe_front_off.png"

minetest.register_node(":firealarm:hornstrobe_on",{
	drop = "firealarm:hornstrobe_off",
	description = "Fire Alarm (wait, why do you have this?)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		{
			name = hornstrobeOnFrontTexture,
			animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 1,
			},
		}
	},
	paramtype = "light",
	paramtype2 = "facedir",
	light_source = 10,
	use_texture_alpha = "blend",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5,-0.5,0.4,0.5,0.5,0.401},
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
})

minetest.register_node(":firealarm:remotestrobe_off",{
	description = "Fire Alarm (Lights only)",
	groups = { oddly_breakable_by_hand = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		"firealarm_hornstrobe_remotestrobe_front_off.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("notification",pos,{strobeActive = false,hornActive = false})
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("notification",pos,nil)
	end,
})

local remoteStrobeOnFrontTexture = "[combine:32x320"..
                                 ":0,0=firealarm_hornstrobe_front_on.png"..
                                 ":0,32=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,64=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,96=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,128=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,160=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,192=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,224=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,256=firealarm_hornstrobe_remotestrobe_front_off.png"..
                                 ":0,288=firealarm_hornstrobe_remotestrobe_front_off.png"

minetest.register_node(":firealarm:remotestrobe_on",{
	drop = "firealarm:remotestrobe_off",
	description = "Fire Alarm (Lights only) (on state - you hacker you!)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		{
			name = remoteStrobeOnFrontTexture,
			animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 1,
			},
		}
	},
	paramtype = "light",
	paramtype2 = "facedir",
	light_source = 10,
	use_texture_alpha = "blend",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.5,-0.5,0.4,0.5,0.5,0.401},
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
})

minetest.register_node(":firealarm:hornstrobe_old_off",{
	description = "Buzzer Fire Alarm",
	groups = { oddly_breakable_by_hand = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		"firealarm_hornstrobe_old_front_off.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("notification",pos,{strobeActive = false,hornActive = false})
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("notification",pos,nil)
	end,
})

local oldHornStrobeOnFrontTexture = "[combine:64x128"..
                                 ":0,0=firealarm_hornstrobe_old_front_on.png"..
                                 ":0,64=firealarm_hornstrobe_old_front_off.png"

minetest.register_node(":firealarm:hornstrobe_old_on",{
	drop = "firealarm:hornstrobe_old_off",
	description = "Buzzer Fire Alarm (on state - you hacker you!)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
	tiles = {
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_top.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_side.png",
		"firealarm_hornstrobe_back.png",
		{
			name = oldHornStrobeOnFrontTexture,
			animation = {
				type = "vertical_frames",
				aspect_w = 64,
				aspect_h = 64,
				length = 0.6,
			},
		}
	},
	paramtype = "light",
	paramtype2 = "facedir",
	light_source = 10,
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.15,-0.02,0.4,0.18,0.37,0.5},
		},
	},
})

minetest.register_node(":firealarm:hornstrobe_german_off",{
	description = "German Fire Alarm",
	groups = { oddly_breakable_by_hand = 1 },
        tiles = {
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_bottom.png",
        },
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
                        {-0.175,-0.175,0.375,0.175,0.175,0.5}, --box

                        {-0.175,-0.175,0.25,-0.159090909091,0.175,0.375}, --wall left
                        {0.159090909091,-0.175,0.25,0.175,0.175,0.375}, --wall right
                        {-0.175,-0.175,0.25,0.175,-0.159090909091,0.375}, --wall down
                        {-0.175,0.159090909091,0.25,0.175,0.175,0.375}, --wall up

                        {-0.175,-0.03125,0.25,0.175,0.03125,0.3}, --connect h
                        {-0.03125,-0.175,0.25,0.03125,0.175,0.3}, --connect v

                        {-0.1,-0.1,0.2,0.1,0.1,0.375}, --lamp
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("notification",pos,{strobeActive = false,hornActive = false})
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("notification",pos,nil)
	end,
})

local germanHornstrobeOnFrontTexture = "[combine:92x920"..
                                      ":0,0=firealarm_hornstrobe_german_bottom_on.png"..
                                      ":0,92=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,184=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,276=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,368=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,460=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,552=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,644=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,736=firealarm_hornstrobe_german_bottom.png"..
                                      ":0,828=firealarm_hornstrobe_german_bottom.png"

minetest.register_node(":firealarm:hornstrobe_german_on",{
	drop = "firealarm:hornstrobe_german_off",
	description = "German Fire Alarm (wait, why do you have this?)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
        tiles = {
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                "firealarm_hornstrobe_german_side.png",
                {
                	name = germanHornstrobeOnFrontTexture,
                        animation = {
                                type = "vertical_frames",
                                aspect_w = 92,
                                aspect_h = 92,
                                length = 1,
                        },
                },
        },
	paramtype = "light",
	paramtype2 = "facedir",
	light_source = 10,
	use_texture_alpha = "blend",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
                        {-0.175,-0.175,0.375,0.175,0.175,0.5}, --box

                        {-0.175,-0.175,0.25,-0.159090909091,0.175,0.375}, --wall left
                        {0.159090909091,-0.175,0.25,0.175,0.175,0.375}, --wall right
                        {-0.175,-0.175,0.25,0.175,-0.159090909091,0.375}, --wall down
                        {-0.175,0.159090909091,0.25,0.175,0.175,0.375}, --wall up

                        {-0.175,-0.03125,0.25,0.175,0.03125,0.3}, --connect h
                        {-0.03125,-0.175,0.25,0.03125,0.175,0.3}, --connect v

                        {-0.1,-0.1,0.2,0.1,0.1,0.375}, --lamp
		},
	},
})

minetest.register_node(":firealarm:hornstrobe_uk_off",{
	description = "UK Fire Alarm",
	groups = { oddly_breakable_by_hand = 1 },
        tiles = {
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_bottom.png",
        },
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
                        {-0.175,-0.175,0.375,0.175,0.175,0.5}, --box

                        {-0.175,-0.175,0.25,-0.159090909091,0.175,0.375}, --wall left
                        {0.159090909091,-0.175,0.25,0.175,0.175,0.375}, --wall right
                        {-0.175,-0.175,0.25,0.175,-0.159090909091,0.375}, --wall down
                        {-0.175,0.159090909091,0.25,0.175,0.175,0.375}, --wall up

                        {-0.175,-0.03125,0.25,0.175,0.03125,0.3}, --connect h
                        {-0.03125,-0.175,0.25,0.03125,0.175,0.3}, --connect v

                        {-0.1,-0.1,0.2,0.1,0.1,0.375}, --lamp
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("notification",pos,{strobeActive = false,hornActive = false})
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("notification",pos,nil)
	end,
})

local ukHornstrobeOnFrontTexture = "[combine:92x920"..
                                      ":0,0=firealarm_hornstrobe_uk_bottom_on.png"..
                                      ":0,92=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,184=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,276=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,368=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,460=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,552=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,644=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,736=firealarm_hornstrobe_uk_bottom.png"..
                                      ":0,828=firealarm_hornstrobe_uk_bottom.png"

minetest.register_node(":firealarm:hornstrobe_uk_on",{
	drop = "firealarm:hornstrobe_uk_off",
	description = "UK Fire Alarm (wait, why do you have this?)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
        tiles = {
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                "firealarm_hornstrobe_uk_side.png",
                {
                	name = ukHornstrobeOnFrontTexture,
                        animation = {
                                type = "vertical_frames",
                                aspect_w = 92,
                                aspect_h = 92,
                                length = 1,
                        },
                },
        },
	paramtype = "light",
	paramtype2 = "facedir",
	light_source = 10,
	use_texture_alpha = "blend",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
                        {-0.175,-0.175,0.375,0.175,0.175,0.5}, --box

                        {-0.175,-0.175,0.25,-0.159090909091,0.175,0.375}, --wall left
                        {0.159090909091,-0.175,0.25,0.175,0.175,0.375}, --wall right
                        {-0.175,-0.175,0.25,0.175,-0.159090909091,0.375}, --wall down
                        {-0.175,0.159090909091,0.25,0.175,0.175,0.375}, --wall up

                        {-0.175,-0.03125,0.25,0.175,0.03125,0.3}, --connect h
                        {-0.03125,-0.175,0.25,0.03125,0.175,0.3}, --connect v

                        {-0.1,-0.1,0.2,0.1,0.1,0.375}, --lamp
		},
	},
})

minetest.register_abm({
	label = "Update horn/strobe state",
	nodenames = {"firealarm:hornstrobe_off","firealarm:hornstrobe_on"},
	interval = 14,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("notification",pos)
		if not devInfo then return end
		if node.name == "firealarm:hornstrobe_off" and devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_on"
			minetest.set_node(pos,node)
		elseif node.name == "firealarm:hornstrobe_on" and not devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_off"
			minetest.set_node(pos,node)
		end
		if devInfo.hornActive then
			minetest.sound_play("firealarm_horn",{pos=pos})
		end
	end,
})

minetest.register_abm({
	label = "Update remote strobe state",
	nodenames = {"firealarm:remotestrobe_off","firealarm:remotestrobe_on"},
	interval = 1,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("notification",pos)
		if not devInfo then return end
		if node.name == "firealarm:remotestrobe_off" and devInfo.strobeActive then
			node.name = "firealarm:remotestrobe_on"
			minetest.set_node(pos,node)
		elseif node.name == "firealarm:remotestrobe_on" and not devInfo.strobeActive then
			node.name = "firealarm:remotestrobe_off"
			minetest.set_node(pos,node)
		end
	end,
})

minetest.register_abm({
	label = "Update horn/light plate state",
	nodenames = {"firealarm:hornstrobe_old_off","firealarm:hornstrobe_old_on"},
	interval = 3,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("notification",pos)
		if not devInfo then return end
		if node.name == "firealarm:hornstrobe_old_off" and devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_old_on"
			minetest.set_node(pos,node)
		elseif node.name == "firealarm:hornstrobe_old_on" and not devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_old_off"
			minetest.set_node(pos,node)
		end
		if devInfo.hornActive then
			minetest.sound_play("firealarm_horn_old",{pos=pos})
		end
	end,
})

minetest.register_abm({
	label = "Update horn/strobe state",
	nodenames = {"firealarm:hornstrobe_german_off","firealarm:hornstrobe_german_on"},
	interval = 1.075,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("notification",pos)
		if not devInfo then return end
		if node.name == "firealarm:hornstrobe_german_off" and devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_german_on"
			minetest.set_node(pos,node)
		elseif node.name == "firealarm:hornstrobe_german_on" and not devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_german_off"
			minetest.set_node(pos,node)
		end
		if devInfo.hornActive then
			minetest.sound_play("firealarm_horn_german",{pos=pos})
		end
	end,
})

minetest.register_abm({
	label = "Update horn/strobe state",
	nodenames = {"firealarm:hornstrobe_uk_off","firealarm:hornstrobe_uk_on"},
	interval = 3,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("notification",pos)
		if not devInfo then return end
		if node.name == "firealarm:hornstrobe_uk_off" and devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_uk_on"
			minetest.set_node(pos,node)
		elseif node.name == "firealarm:hornstrobe_uk_on" and not devInfo.strobeActive then
			node.name = "firealarm:hornstrobe_uk_off"
			minetest.set_node(pos,node)
		end
		if devInfo.hornActive then
			minetest.sound_play("firealarm_horn_uk",{pos=pos})
		end
	end,
})

minetest.register_craft({
	output = "firealarm:hornstrobe_off",
	recipe = {
		{"","mesecons_lightstone:lightstone_white_off","",},
		{"dye:white","homedecor:speaker_driver","dye:white",},
		{"","plasticbox:plasticbox","homedecor:ic",},
	}
})

minetest.register_craft({
	output = "firealarm:remotestrobe_off",
	recipe = {
		{"","mesecons_lightstone:lightstone_white_off","",},
		{"dye:white","","dye:white",},
		{"","plasticbox:plasticbox","homedecor:ic",},
	}
})

minetest.register_craft({
	output = "firealarm:hornstrobe_old_off",
	recipe = {
		{"","ilights:light","",},
		{"dye:white","homedecor:speaker_driver","dye:white",},
		{"","plasticbox:plasticbox","",},
	}
})

minetest.register_craft({
	output = "firealarm:hornstrobe_german_off",
	recipe = {
		{"","mesecons_lightstone:lightstone_red_off","",},
		{"dye:white","homedecor:speaker_driver","dye:white",},
		{"","plasticbox:plasticbox","homedecor:ic",},
	}
})

minetest.register_craft({
	output = "firealarm:hornstrobe_uk_off",
	recipe = {
		{"","","",},
		{"dye:white","homedecor:speaker_driver","dye:white",},
		{"plasticbox:plasticbox","mesecons_lightstone:lightstone_red_off","homedecor:ic",},
	}
})





--[[ UK/German
local smokeDetectorOffBottomTexture = "[combine:32x320"..
                                      ":0,0=firealarm_smokedetector_bottom_on.png"..
                                      ":0,32=firealarm_smokedetector_bottom_off.png"..
                                      ":0,64=firealarm_smokedetector_bottom_off.png"..
                                      ":0,96=firealarm_smokedetector_bottom_off.png"..
                                      ":0,128=firealarm_smokedetector_bottom_off.png"..
                                      ":0,160=firealarm_smokedetector_bottom_off.png"..
                                      ":0,192=firealarm_smokedetector_bottom_off.png"..
                                      ":0,224=firealarm_smokedetector_bottom_off.png"..
                                      ":0,256=firealarm_smokedetector_bottom_off.png"..
                                      ":0,288=firealarm_smokedetector_bottom_off.png"

minetest.register_node(":firealarm:smokedetector_off",{
	description = "Fire Alarm Smoke Detector",
	groups = { oddly_breakable_by_hand = 1 },
	tiles = {
		"firealarm_smokedetector_sides.png",
		{
			name = smokeDetectorOffBottomTexture,
			animation = {
				type = "vertical_frames",
				aspect_w = 32,
				aspect_h = 32,
				length = 5,
			},
		},
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.2,0.4,-0.2,0.2,0.5,0.2},
			{-0.075,0.35,-0.075,0.075,0.4,0.075},
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
		local item = player:get_wielded_item()
		if item and string.find(item:get_name(),"magnet") then
			--Simulate the effect of the old beehive smoker
			minetest.get_meta(pos):set_int("agressive",0)
		end
	end,
	after_place_node = function(pos)
		firealarm.setDevInfo("signaling",pos,{active = false,manualReset = false})
		minetest.get_meta(pos):set_int("agressive",1)
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("signaling",pos,nil)
	end,
})

minetest.register_node(":firealarm:smokedetector_on",{
	drop = "firealarm:smokedetector_off",
	description = "Fire Alarm Smoke Detector (on state - you hacker you!)",
	groups = { oddly_breakable_by_hand = 1,not_in_creative_inventory = 1 },
	tiles = {
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_bottom_on.png",
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
		"firealarm_smokedetector_sides.png",
	},
	paramtype = "light",
	paramtype2 = "facedir",
	drawtype = "nodebox",
	node_box = {
		type = "fixed",
		fixed = {
			{-0.2,0.4,-0.2,0.2,0.5,0.2},
			{-0.075,0.35,-0.075,0.075,0.4,0.075},
		},
	},
	on_punch = function(pos,_,player)
		local name = player:get_player_name()
		minetest.chat_send_player(name,string.format("Position: %d,%d,%d",pos.x,pos.y,pos.z))
	end,
	after_dig_node = function(pos)
		firealarm.setDevInfo("signaling",pos,nil)
	end,
})

minetest.register_abm({
	label = "Check for fire",
	nodenames = {"firealarm:smokedetector_off"},
	interval = 5,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("signaling",pos)
		if not devInfo then return end
		local minheight
		for i=-1,-10,-1 do
			local checkpos = vector.add(pos,vector.new(0,i,0))
			local ndef = minetest.registered_nodes[minetest.get_node(checkpos).name]
			if ndef and ndef.drawtype == "normal" then
				minheight = i
				break
			end
		end
		minheight = minheight or -10
		local minp = vector.add(pos,vector.new(-4,minheight,-4))
		local maxp = vector.add(pos,vector.new(4,0,4))
		local fire_nodes = {"fire:permanent_flame","fire:basic_flame","tnt:gunpowder_burning","default:lava_source","default:lava_flowing"}
		local fire = #minetest.find_nodes_in_area(minp,maxp,fire_nodes) > 0
		if fire or minetest.get_meta(pos):get_int("agressive") == 0 then
			devInfo.active = true
			firealarm.setDevInfo("signaling",pos,devInfo)
			node.name = "firealarm:smokedetector_on"
			minetest.set_node(pos,node)
			if devInfo.associated then
				local panelPos = minetest.get_position_from_hash(devInfo.associated)
				if panelPos then firealarm.loadNode(panelPos) end
				if type(firealarm.panelABM) == "function" then firealarm.panelABM(pos) end
			end
		end
	end,
})

minetest.register_abm({
	label = "Reset LED",
	nodenames = {"firealarm:smokedetector_on"},
	interval = 1,
	chance = 1,
	action = function(pos,node)
		local devInfo = firealarm.getDevInfo("signaling",pos)
		if (not devInfo) or devInfo.active then return end
		node.name = "firealarm:smokedetector_off"
		minetest.set_node(pos,node)
		minetest.get_meta(pos):set_int("agressive",1)
	end,
})

minetest.register_craft({
	output = "firealarm:smokedetector_off",
	recipe = {
		{"plasticbox:plasticbox","homedecor:ic","plasticbox:plasticbox",},
		{"homedecor:copper_strip","technic:uranium_lump","homedecor:copper_strip",},
		{"","plasticbox:plasticbox","mesecons_lightstone:lightstone_red_off",},
	}
})

minetest.register_craft({
	output = "firealarm:smokedetector_off",
	recipe = {
		{"plasticbox:plasticbox","homedecor:ic","plasticbox:plasticbox",},
		{"mesecons_lamp:lamp_off","","mesecons_solarpanel:solar_panel_off",},
		{"","plasticbox:plasticbox","mesecons_lightstone:lightstone_red_off",},
	}
})
]]